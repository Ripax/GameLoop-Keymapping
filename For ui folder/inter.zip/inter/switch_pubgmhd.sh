#!/bin/sh
if [ -d /data/app/com.tencent.tmgp.pubgmhd-1/lib/arm64 ]; then
	rm -rf /data/app/com.tencent.tmgp.pubgmhd-1/lib/arm
fi
if [ -d /data/app/com.tencent.tmgp.pubgmhd-2/lib/arm64 ]; then
	rm -rf /data/app/com.tencent.tmgp.pubgmhd-2/lib/arm
fi