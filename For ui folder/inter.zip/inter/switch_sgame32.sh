#!/bin/sh
if [ -d /data/app/com.tencent.tmgp.sgame-1/lib/arm ]; then
	rm -rf /data/app/com.tencent.tmgp.sgame-1/lib/arm64
fi
if [ -d /data/app/com.tencent.tmgp.sgame-2/lib/arm ]; then
	rm -rf /data/app/com.tencent.tmgp.sgame-2/lib/arm64
fi