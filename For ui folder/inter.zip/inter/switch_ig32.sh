#!/bin/sh
if [ -d /data/app/com.tencent.ig-1/lib/arm ]; then
	rm -rf /data/app/com.tencent.ig-1/lib/arm64
fi
if [ -d /data/app/com.tencent.ig-2/lib/arm ]; then
	rm -rf /data/app/com.tencent.ig-2/lib/arm64
fi