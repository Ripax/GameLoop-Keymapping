#!/bin/sh
if [ -d /data/app/com.rekoo.pubgm-1/lib/arm ]; then
	rm -rf /data/app/com.rekoo.pubgm-1/lib/arm64
fi
if [ -d /data/app/com.rekoo.pubgm-2/lib/arm ]; then
	rm -rf /data/app/com.rekoo.pubgm-2/lib/arm64
fi